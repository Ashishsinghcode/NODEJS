const router = require('express').Router()
var catagoryController=require('../controllers/catagoryController')
var orderController=require('../controllers/orderController')
var cartController=require('../controllers/cartController')
var productController=require('../controllers/productController')
let usercontroller = require('../controllers/userController')
let gallarycontroller = require('../controllers/gallaryController')


const multer = require('multer')
const profilepicstorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './public/profilepic')
    },
    filename: function (req, file, cb) {
        
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      const new_name = uniqueSuffix+file.originalname
      cb(null, file.fieldname + '-' + new_name)
    }
  })
  
  const profilepic_upload = multer({ storage: profilepicstorage })


  
const gallarystorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './public/gallary')
    },
    filename: function (req, file, cb) {
        
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      const new_name = uniqueSuffix+file.originalname
      cb(null, file.fieldname + '-' + new_name)
    }
  })
  
  const gallary_upload = multer({ storage: gallarystorage })

router.post('/login', usercontroller.login)
router.post('/addcustomer',profilepic_upload.single('profile_pic') ,usercontroller.register)
router.post('/viewproduct',productController.viewProduct)


//router.use(require('../common/adminMiddleware'))
//User API start
router.post('/listcustomer', usercontroller.listcustomer)
router.post('/changepassword', usercontroller.changepass)
//USer API end
//Catagory API
router.post('/addcatagory',catagoryController.addCatagory)
router.post('/addproduct',productController.addProduct)
//router.post('/viewcatagory',catagoryController.viewCatagory)
//ENd Catagory API


//product API

//end product API
//order API start
router.post('/placeorder',orderController.addOrder)
router.post('/vieworder',orderController.viewOrder)
router.post('/addtocart',cartController.addcart)
router.post('/viewcart',cartController.viewCart)
//order API end
router.post('/addgallary',gallary_upload.array('gallary') ,gallarycontroller.addgallary)



//ERROR PAGE
router.all("**",function(req,res){
    res.json({
        'status':404,
        'success':false,
        'message':'Page not found'
    })
})
//END ERROR PAGE
module.exports = router